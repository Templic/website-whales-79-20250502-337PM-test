
/// <reference types="vite/client" />
/// <reference path="./types/speechRecognition.d.ts" />
