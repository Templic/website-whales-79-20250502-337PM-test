export function LoadingBackground() {
  return <div className="fixed inset-0 -z-10 bg-gradient-to-b from-[#080315] via-[#120728] to-[#080315]" />
}

